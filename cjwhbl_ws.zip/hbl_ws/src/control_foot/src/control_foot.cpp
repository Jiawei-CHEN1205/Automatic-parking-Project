#include<stdlib.h>
#include<opencv2/opencv.hpp>
#include"ros/ros.h"
#include <iostream>
#include<geometry_msgs/Twist.h>

#define STOP 0

using namespace std;
using namespace cv;
/***************************************************************/
//相关的函数

int main(int argc, char **argv) {
    VideoCapture capture;
    capture.open(0);//打开zed相机

/*****************************************************/
//position.x=0.0;
//position.y=0.0;
//中心坐标点初始化

    int M=0,B=0;

Mat kernel;
    ROS_WARN("**START");
    ros::init(argc, argv, "trafficLaneTrack");//初始化ROS节点
    ros::NodeHandle n;
    ros::Publisher pub = n.advertise<geometry_msgs::Twist>("/smoother_cmd_vel", 5);//定义速度发布器
    //ros::Rate loop_rate(5);
    kernel = getStructuringElement(MORPH_RECT,Size(30,30),Point(20,20));


    while (waitKey(1)) {


        Mat raw,gray;
        capture.read(raw);
        raw = raw(cv::Rect(0, 0, raw.cols / 2, raw.rows));
	imshow("origin",raw);
        int rows = raw.rows, cols = raw.cols;
        cv:cvtColor(raw,gray,COLOR_BGR2GRAY);
        threshold(gray,gray,35,255,THRESH_BINARY_INV);

        erode(gray,gray,kernel,Point(1,1),1,1);
        dilate(gray,gray,kernel,Point(1,1),1,1);

        imshow("raw", gray);
/**************************************************************************/
 /* 预处理*/
 int a=0;
 int a_x=0,a_y=0;
 for(int i=0;i<rows;i++)
 {
     for (int j=0;j<cols;j++)
     {

         if(gray.at<uchar >(i,j)>200)
         {
          a++;
          a_x=a_x+i;
          a_y=a_y+j;
         }
     }
 }

/************************************************************************/

    geometry_msgs::Twist cmd_red;
//车的速度值设置
        cmd_red.linear.y =0;
        cmd_red.linear.z = 0;
        cmd_red.angular.x=0;
        cmd_red.angular.y=0;
        cmd_red.linear.x = 0;


        a_y=a_y/(float)a;
        cmd_red.linear.x =-(a-110000)*0.000005;
        cmd_red.angular.z = -(a_y-336)*0.005;


        if(a<10000)
        {
            cmd_red.linear.x =0;
            cmd_red.angular.z = 0;
        }


//if( M==0)
//{
//    cmd_red.linear.x = 0.25;
//    cmd_red.angular.z = -(sumx-1390)*0.001;
//}
//if(area>18000) M=1;
//if(M==1&&B<10000)
//{
//    cmd_red.linear.x = 0.2;
//    cmd_red.angular.z = 0.0;
//    B++;
//}
//if (position.x==0&&position.y==0)
//{
//    cmd_red.linear.x = STOP;
//    cmd_red.angular.z= STOP;
//}
pub.publish(cmd_red);
cout<<""<< cmd_red.linear.x<<endl;

ros::spinOnce();


    }
    return 0;
}






















 


